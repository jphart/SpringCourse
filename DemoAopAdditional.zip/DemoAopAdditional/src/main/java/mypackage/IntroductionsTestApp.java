package mypackage;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class IntroductionsTestApp {

	public static void main(String[] args) {

		AbstractApplicationContext context = new ClassPathXmlApplicationContext("app-config.xml");
		MyService bean = (MyService) context.getBean("myservice");

		try {
			bean.goodOp1();
			bean.goodOp2();
			bean.badOp();

		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}

		CallTracker t = (CallTracker) bean;
		System.out.println("Bean tracking details: " + t.describe());

		context.close();
	}
}
