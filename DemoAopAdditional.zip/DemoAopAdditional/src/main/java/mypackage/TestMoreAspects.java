package mypackage;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestMoreAspects {

	public static void main(String[] args) {
		
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("app-config.xml");

		BankServiceInterface service = (BankServiceInterface)context.getBean("service");
		service.doDeposit(1, 100);
		service.doWithdraw(1, 25);
		
		context.close();
	}
}
