package mypackage;

public interface MyService {
	void goodOp1();
	void goodOp2();
	void badOp() throws Exception;
}
